package Final;

import java.util.ArrayList;
import java.util.Comparator;



public class Collections_questions {
	//Q3: Implement Static method reverse_array that returns a reversed student array.
	//Use the array passed in from the Driver class.
}

class Student implements Comparable<Student> {
	float gpa;
	String name;
	
	public Student(float g, String n) {
		gpa = g;
		name = n;
	}
	
	//Q1: Implement Comparable interface for Student's name (alphabetically). (yes I know there should be a last and first. Trying to keep this simple for you)
	
	public int compareTo(Student s) {
		return s.name.compareTo(name);
		
	}


//Q2: Create and implement Student_gpa_Comparator, order GPA from HIGH to low
	public int Student_gpa_Comparator(Student s) {
		if(this.gpa > s.gpa) {
			return 1;
		}
		else if (this.gpa < s.gpa) {
			return -1;
		}
		return 0;
	}
}
